#!/usr/bin/python
#coding:utf-8
import urllib
import urllib2
from HTMLParser import HTMLParser
import xlrd
from xlutils.copy import copy
import sys
import re
import os
reload(sys)  
sys.setdefaultencoding('utf-8')
s_excelName =u"备案价格lyj.xls"
s_tag = "td"
s_decode = "GBK"
s_oneMaxCount = 1000

s_jumpKeyList = [u"套房详细信息", u"预售查丈"]
s_endKey = u"竣工查丈"

class HtmlParser(HTMLParser):
	# 继承父类初始化方法，并添加一个tag属性
	def __init__(self, htmlId):
		HTMLParser.__init__(self)
		self.tag = None
		self.count = 0
		self.end = False
		self.excelKeyList = []
		self.excelDataList = []
		self.htmlId = htmlId

	def handle_starttag(self, tag, attrs):
		if tag == s_tag:
			self.tag = s_tag

	def getHtmlData(self, data):
		if s_decode:
			return data.decode(s_decode)
		else:
			return data
	def getNotNoneData(self, htmlData):
		strData = htmlData.replace("\f", "")
		strData = strData.replace("\t", "")
		strData = strData.replace("\r", "")
		strData = strData.replace("\n", "")
		strData = strData.replace(" ", "")
		return strData

	def findIsJump(self, htmlData):
		if 0 == len(htmlData):
			return True
		elif self.end:
			return True
		else:
			for _,jumpKey in enumerate(s_jumpKeyList):
				if -1 != htmlData.find(jumpKey):
					return True
		return False

	def handle_data(self, data):
		if self.tag == s_tag and len(data):
			htmlData = self.getHtmlData(data)
			htmlData = self.getNotNoneData(htmlData)
			if self.findIsJump(htmlData):
				return
			elif -1 != htmlData.find(s_endKey):
				self.end = True
				self.putExcel()
				return
			else:
				self.count = self.count + 1
				if self.count % 2 == 0:
					self.excelDataList.append(htmlData)
				else:
					self.excelKeyList.append(htmlData)

	def putExcel(self):
		excelWork = xlrd.open_workbook(s_excelName)
		booksheet = excelWork.sheets()[0]
		#获取行数
		allRow = booksheet.nrows
		writeExcel = copy(excelWork)
		writeSheet = writeExcel.get_sheet(0)
		if 0 == allRow:
			for index,excelKey in enumerate(self.excelKeyList):
				writeSheet.write(allRow, index, excelKey)
			writeSheet.write(allRow, index + 1, u"网页ID")
			allRow = allRow + 1
		for index,excelData in enumerate(self.excelDataList):
			writeSheet.write(allRow, index, excelData)
		writeSheet.write(allRow, index + 1, self.htmlId)
		writeExcel.save(s_excelName)

def getScriptDirectory():
	return os.path.dirname(os.path.realpath(__file__))

def readHtml(htmlId):
	url = "http://ris.szpl.gov.cn/bol/housedetail.aspx?id=" + str(htmlId)
	request = urllib2.Request(url)
	response = urllib2.urlopen(request)
	htmlData = response.read()
	htmlPr = HtmlParser(htmlId)
	htmlPr.feed(htmlData)

def checkExcelFile():
	if False == os.path.exists(s_excelName):
		print(u"" + getScriptDirectory() + "\下不存在文件  " + s_excelName + "  请创建")
		exit()

def getStartId():
	print(u"请输入开始的网页ID,例如:13800:")
	startID = raw_input("").strip()
	if 0 == len(startID):
		return getStartId()
	elif re.match(r"\d+$", startID):
		return int(startID)
	else:
		return getStartId()

def main():
	checkExcelFile()
	startID = getStartId() - 1
	print(u"请等待 ........")
	for index in xrange(1,s_oneMaxCount + 1):
		print u"正在读取第 ", index, u"个数据，网页ID = ", index + startID 
		readHtml(index + startID)

if __name__ == '__main__':
	main()

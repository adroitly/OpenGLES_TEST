=======
xlutils
=======

For full documentation please see:
http://www.simplistix.co.uk/software/python/xlutils

If working offline, please consult the documentation source in the
`docs` directory.

Licensing
=========

Copyright (c) 2008-2012 Simplistix Ltd
See docs/license.txt for details.
